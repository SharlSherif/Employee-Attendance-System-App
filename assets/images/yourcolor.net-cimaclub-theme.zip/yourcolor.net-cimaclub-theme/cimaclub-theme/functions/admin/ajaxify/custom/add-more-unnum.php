<?
ob_start();
define('WP_USE_THEMES', false);
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
?>
<? wp_delete_post($_GET['id']); ?>
<? require_once TEMPLATEPATH.'/admin/YC-opt.php'; ?>
<? foreach( $options as $option ) { ?>
	<? $pid = wp_insert_post( 
        array(
            'post_title'=>$option['id'],
            'post_status'=>'publish',
            'post_type'=>'theme_op',
        )
    );
    ?>
    <div class="more-list">
        <? foreach( $option['fields'] as $optfield ) { ?>
            <label for="<?=$optfield['id']?>"><?=$optfield['name']?></label>
            <input id="<?=$optfield['id']?>" name="<?=$optfield['id']?>_<?=$pid?>" /><br>
        <? } ?>
        <input value="حذف" type="submit" name="remove_<?=$kys?>" />
    </div><br /><br />
<? } ?>