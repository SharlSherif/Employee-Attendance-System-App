<?
ob_start();
define('WP_USE_THEMES', false);
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
?>
<? require_once TEMPLATEPATH.'/admin/YC-opt.php'; ?>
<? foreach( $options as $option ) { ?>
    <? if( $option['id'] == $_GET['option'] ) { ?>
        <? $pid = wp_insert_post( 
			array(
				'post_title'=>$option['id'],
				'post_status'=>'publish',
				'post_type'=>'theme_op',
			)
		);
		?>
        <div class="more-list">
        	<? foreach( $option['fields'] as $optfield ) { ?>
            	<? if( $optfield['type'] == 'upload' ) { ?>
					<script>
                        jQuery(document).ready(function($) {
                            $('.<?=$optfield['id']?>_<?=$kys?>_upload').click(function(e) {
                                e.preventDefault();
                    
                                var custom_uploader = wp.media({
                                    title: '<?=$optfield['name']?>',
                                    button: {
                                        text: 'رفع صورة'
                                    },
                                    multiple: false  // Set this to true to allow multiple files to be selected
                                })
                                .on('select', function() {
                                    var attachment = custom_uploader.state().get('selection').first().toJSON();
                                    $('img.<?=$optfield['id']?>_<?=$kys?>').attr('src', attachment.url);
                                    $('.<?=$optfield['id']?>_<?=$kys?>_url').val(attachment.url);
                                    $('.<?=$optfield['id']?>_<?=$kys?>_remove').show();
                                })
                                .open();
                            });
                            jQuery(".<?=$optfield['id']?>_<?=$kys?>_remove").click(function(){
                                $('img.<?=$optfield['id']?>_<?=$kys?>').attr('src', "");
                                $('.<?=$optfield['id']?>_<?=$kys?>_url').val("");
                                $('.<?=$optfield['id']?>_<?=$kys?>_remove').hide();
                            });
                        });
                    </script>
                    <? if( $_POST[$optfield['id'].'_'.$kys] ) { ?>
                        <? update_option( ''.$optfield['id'].'_'.$kys.'', $_POST[$optfield['id'].'_'.$kys] ); ?>
                    <? } ?>
                    <div>
                        <label for="<?=$optfield['id']?>"><?=$optfield['name']?></label>
                        <img src="<? echo get_option(''.$optfield['id'].'_'.$kys.''); ?>" class="<?=$optfield['id']?>_<?=$kys?>" style="width:50px;float:right;" />
                        <a class="<?=$optfield['id']?>_<?=$kys?>_upload">رفع الصورة</a>
                        <a class="<?=$optfield['id']?>_<?=$kys?>_remove" <? if( get_option(''.$optfield['id'].'_'.$kys.'') == '' ) { ?>style="display:none;"<? } ?>>ازالة الصورة</a>
                        <input class="<?=$optfield['id']?>_<?=$kys?>_url" value="<? echo get_option(''.$optfield['id'].'_'.$kys.''); ?>" id="<?=$optfield['id']?>" name="<?=$optfield['id']?>_<?=$kys?>" /><br>
                    </div>
                <? }elseif( $optfield['type'] == 'text' ) { ?>
                    <? if( $_POST[$optfield['id'].'_'.$kys] ) { ?>
                        <? update_option( ''.$optfield['id'].'_'.$kys.'', $_POST[$optfield['id'].'_'.$kys] ); ?>
                    <? } ?>
                    <div>
                        <label for="<?=$optfield['id']?>"><?=$optfield['name']?></label>
                        <input value="<? echo get_option(''.$optfield['id'].'_'.$kys.''); ?>" id="<?=$optfield['id']?>" name="<?=$optfield['id']?>_<?=$kys?>" /><br>
                    </div>
                <? }elseif( $optfield['type'] == 'textarea' ) { ?>
                    <? if( $_POST[$optfield['id'].'_'.$kys] ) { ?>
                        <? update_option( ''.$optfield['id'].'_'.$kys.'', $_POST[$optfield['id'].'_'.$kys] ); ?>
                    <? } ?>
                    <div>
                        <label for="<?=$optfield['id']?>"><?=$optfield['name']?></label>
                        <textarea id="<?=$optfield['id']?>" name="<?=$optfield['id']?>_<?=$kys?>"><? echo get_option(''.$optfield['id'].'_'.$kys.''); ?></textarea><br>
                    </div>
                <? }elseif( $optfield['type'] == 'editor' ) { ?>
                    <? if( $_POST[$optfield['id'].'_'.$kys] ) { ?>
                        <? update_option( ''.$optfield['id'].'_'.$kys.'', $_POST[$optfield['id'].'_'.$kys] ); ?>
                    <? } ?>
                    <div>
                        <label for="<?=$optfield['id']?>"><?=$optfield['name']?></label>
                        <?php 
                         $textarea_name = $optfield['id'].'_'.$kys;
                         $editor_id = $optfield['id'].'_'.$kys;
                         wp_editor( 
                             get_option(''.$optfield['id'].'_'.$kys.''), 
                             $editor_id, 
                             $settings = array( 
                                 'media_buttons' => true,
                                 'textarea_name' => $textarea_name,
                                 'quicktags' => true,
                                 'tinymce' => true,
                                 'textarea_rows' => 20,
                             )
                         ); 
                        ?>
                    </div>
                <? } ?>
            <? } ?>
            <input value="حذف" type="submit" name="remove_<?=$kys?>" />
        </div><br /><br />
    <? } ?>
<? } ?>