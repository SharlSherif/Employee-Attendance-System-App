<?
////////////////////////////////////////////////////////
// Statics
////////////////////////////////////////////////////////
?>
<? if( array_key_exists('action', $_POST) ) { ?>
	<? $i = 0; foreach( $options as $option ) { ?>
    	<? if( $option['type'] == 'code' ) { ?>
	        <? update_option($option['id'],stripslashes(wp_filter_post_kses(addslashes($_POST[$option['id']])))); ?>
        <? }else { ?>
			<? update_option($option['id'],$_POST[$option['id']]); ?>
        <? } ?>
        <? foreach( get_add_more( $option['id'] ) as $kys => $v ) { ?>
            <? if( $_POST['remove_'.$kys.''] ) { ?>
                <? wp_delete_post($kys); ?>
            <? } ?>
        <? } ?>
    <? } ?>
<? } ?>