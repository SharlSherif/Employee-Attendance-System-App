<?php
	/////////////////////////////////////////////////
	// Item Tabs
	/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Categories',
		'id' => 'tab_head_categories',
		'type' => 'tab',
		'icon' => get_template_directory_uri().'/functions/admin/icons/2.png',
	);
	/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Social',
		'id' => 'tab_head_social',
		'type' => 'tab',
		'icon' => get_template_directory_uri().'/functions/admin/icons/3.png',
	);
	/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Contact Us',
		'id' => 'tab_head_contact',
		'type' => 'tab',
		'icon' => get_template_directory_uri().'/functions/admin/icons/4.png',
	);
	/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'اعلانات البوب اب ',
		'id' => 'tab_head_pop',
		'type' => 'tab',
		'icon' => get_template_directory_uri().'/functions/admin/icons/8.png',
	);
	/////////////////////////////////////////////////
	// Item Tabs Id = Categories
	/////////////////////////////////////////////////
	foreach (get_categories(array('taxonomy'=>'category', 'hide_empty'=>0)) as $categ) {
		$options[] = array(
			'name' => $categ->cat_name,
			'id' => 'categ_'.$categ->term_id.'',
			'type' => 'text',
			'to' => 'tab_head_categories'
		);
	}
	/////////////////////////////////////////////////
	// Item Tabs Id = tab_head
	/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'الشعار',
		'id' => 'logo',
		'type' => 'text',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'بانر',
		'id' => 'banner',
		'type' => 'text',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'الخلفية',
		'id' => 'background',
		'type' => 'text',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Facebook',
		'id' => 'facebook',
		'type' => 'text',
		'desc' => 'ضع رابط صفحة الفيس بوك',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Google plus',
		'id' => 'googleplus',
		'type' => 'text',
		'desc' => 'ضع رابط صفحة جوجل بلاس',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Twitter',
		'id' => 'twitter',
		'type' => 'text',
		'desc' => 'ضع رابط صفحة تويتر',
		'to' => 'tab_head_social'
	);
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Youtube',
		'id' => 'youtube',
		'type' => 'text',
		'desc' => 'ضع رابط صفحة يوتيوب',
		'to' => 'tab_head_social'
	);

/////////////////////////////////////////////////
// Item Tabs Id = tab_head
/////////////////////////////////////////////////
	$options[] = array(
		'name' => 'Email Contact',
		'id' => 'email_contact',
		'type' => 'text',
		'to' => 'tab_head_contact',
		
	);

/////////////////////////////////////////////////
// Item Tabs Id = tab_head
/////////////////////////////////////////////////

	$options[] = array(
		'name' => 'عنوان الصفحة الرئيسية',
		'id' => 's_title_home',
		'type' => 'text',
		'to' => 'tab_head_pop',
	);
	$options[] = array(
		'name' => 'وصف الصفحة الرئيسية',
		'id' => 's_description_home',
		'type' => 'text',
		'to' => 'tab_head_pop',
	);
	$options[] = array(
		'name' => 'وسوم الصفحة الرئيسية',
		'id' => 's_tags_home',
		'type' => 'text',
		'to' => 'tab_head_pop',
	);
	$options[] = array(
		'name' => 'عنوان صفحة الخطأ',
		'id' => 's_404',
		'type' => 'text',
		'to' => 'tab_head_pop',
	);
	
	$options[] = array(
		'name' => ' ديسكتوب -اعلان البوب اب ',
		'id' => 'd_pop',
		'type' => 'textarea',
		'to' => 'tab_head_pop',
		
	);


	$options[] = array(
		'name' => ' موبايل -اعلان البوب اب ',
		'id' => 'm_pop',
		'type' => 'textarea',
		'to' => 'tab_head_pop',
		
	);
