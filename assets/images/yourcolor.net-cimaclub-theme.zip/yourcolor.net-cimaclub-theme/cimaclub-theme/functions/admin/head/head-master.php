<?php 
	function YC_admin_style() { 
?>
<style>
*{
	outline:0 !important;	
}
html{
	cursor: url(<?php bloginfo('template_url'); ?>/functions/admin/img/YC-mouse.png) , auto;
	background: url(<?php bloginfo('template_url'); ?>/functions/admin/head/img/bg-2.jpg) bottom center no-repeat fixed !important;
	background-size:100% 100% !important;
}
html:before {
  background: rgba(255, 255, 255, 0.51);
  content: "";
  position: fixed;
  width: 100%;
  top: 0px;
  height: 100%;
  left: 0px;
}
body{
	background-color: transparent !important; 
}
#adminmenuback{
	background: rgba(34, 34, 34, 0.8) !important;
}
#adminmenuwrap , #adminmenu {
	background: none !important;
}
.clr{
	clear:both;
}
.repeatable-grouping{
	background: rgba(255, 255, 255, 0.2);
	background-size: 100% 100%;
	display: block;
	box-shadow: 0 0 6px rgba(0, 0, 0, 0.1);
	margin-bottom: 10px;
	position: relative;
	border: 1px solid rgba(255, 255, 255, 0.2);
	overflow: hidden;
}
.cmb-type-title{
	background:#272727;
}
.cmb-type-title h5{
	color: #FFF;
	font-size: 18px;
}
.form-table th{
	width:auto !important
}
.remove-group-row{
	background-color: #C9302C;
	border-color: #AC2925;
	color: #FFF;
	box-shadow: 0 0 0 0;
	padding: 1px 10px 5px 10px;
	height: 30px;
}
#album_songer, #songs_option{
	background: rgba(0, 0, 0, 0.5);
}
</style>
<?php
	}
	add_action( 'admin_enqueue_scripts', 'YC_admin_style' );
?>