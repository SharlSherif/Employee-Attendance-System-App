<?php // YourColor.Net Option
//////////////////////////////////////////////////////////////////////
// Add More Fields Option
$options[] = array(
	'name' => 'Add More Field',
	'id' => 'images_more2',
	'type' => 'more_field',
	'to' => 'tab_head_2',
	'desc' => 'Example Description Example Description Example Description Example Description .',
	'fields' => array(
		array(
			'name'=>'Field Number',
			'id'=>'field_img_1',
			'type'=>'upload'
		),
		array(
			'name'=>'Field Number',
			'id'=>'field_titl_img',
			'type'=>'text'
		),
		array(
			'name' => 'Select Example',
			'id' => 'select',
			'type' => 'select',
			'to' => 'tab_head',
			'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
			'options' => array(
				'1' => 'Select 1',
				'2' => 'Select 2',
				'3' => 'Select 3',
				'4' => 'Select 4',
				'5' => 'Select 5',
				'6' => 'Select 6',
				'7' => 'Select 7',
				'8' => 'Select 8',
			)
		),
		array(
			'name' => 'Show Editor ?',
			'id' => 'show_editor',
			'type' => 'show_field',
			'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
			'to' => 'tab_head',
			'show' => 'editor'
		),
		array(
			'name' => 'Editor Example',
			'id' => 'editor',
			'type' => 'editor',
			'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
			'to' => 'tab_head'
		),
	)
);
// Add More Fields Include
foreach( get_add_more( 'images_more2' ) as $kys => $v ) {
	echo get_option('field_img_1_'.$kys.'');
}
//////////////////////////////////////////////////////////////////////
// Text Option

$options[] = array(
	'name' => 'Text Input',
	'id' => 'text',
	'type' => 'text',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Text Include
echo get_option('text');
//////////////////////////////////////////////////////////////////////
// Textarea Option

$options[] = array(
	'name' => 'Textarea Example',
	'id' => 'text2',
	'type' => 'textarea',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Textarea Include
echo get_option('text2');
//////////////////////////////////////////////////////////////////////
// Datepicker Option

$options[] = array(
	'name' => 'Date Picker Example',
	'id' => 'date_pick',
	'type' => 'date',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Datepicker Include
echo get_option('date_pick');
//////////////////////////////////////////////////////////////////////
// Colorpicker Option

$options[] = array(
	'name' => 'Color Picker Example',
	'id' => 'color_pick',
	'type' => 'color',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Colorpicker Include
echo get_option('color_pick');
//////////////////////////////////////////////////////////////////////
// Select Option

$options[] = array(
	'name' => 'Select Example',
	'id' => 'select',
	'type' => 'select',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'options' => array(
		'1' => 'Select 1',
		'2' => 'Select 2',
		'3' => 'Select 3',
		'4' => 'Select 4',
		'5' => 'Select 5',
		'6' => 'Select 6',
		'7' => 'Select 7',
		'8' => 'Select 8',
	)
);
// Select Include
echo get_option('select');
//////////////////////////////////////////////////////////////////////
// Taxonomy Select Option

$options[] = array(
	'name' => 'Taxonomy Select',
	'id' => 'taxonomy_select',
	'type' => 'select_taxonomy',
	'tax' => 'category',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Taxonomy Select Include
echo get_option('taxonomy_select');
//////////////////////////////////////////////////////////////////////
// Upload File Option

$options[] = array(
	'name' => 'Upload File',
	'id' => 'upload_file',
	'type' => 'upload',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Upload File Include
echo get_option('upload_file');
//////////////////////////////////////////////////////////////////////
// Editor Option

$options[] = array(
	'name' => 'Editor Example',
	'id' => 'editor',
	'type' => 'editor',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Editor Include
echo get_option('editor');
//////////////////////////////////////////////////////////////////////
// Select Pattern Option

$options[] = array(
	'name' => 'Select Pattern',
	'id' => 'select_pattern',
	'type' => 'select_img',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head',
	'images' => array(
		'1' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'2' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'3' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'4' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'5' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'6' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
		'7' => 'http://mrserv.com/quotes/wp-content/uploads/gru-icon-2.png',
	)
);
// Select Pattern Include
echo get_option('select_pattern');
//////////////////////////////////////////////////////////////////////
// Select Fonts Google Option

$options[] = array(
	'name' => 'Google Fonts',
	'id' => 'google_fonts',
	'type' => 'fonts',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head'
);
// Select Fonts Google Include
echo get_option('google_fonts');
//////////////////////////////////////////////////////////////////////
// Show More Field Option

$options[] = array(
	'name' => 'Show More Field',
	'id' => 'more_field',
	'type' => 'show_field',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'to' => 'tab_head',
	'show' => 'more_field_show'
);
// Show More Field Include
echo get_option('more_field');
//////////////////////////////////////////////////////////////////////
// Radio Option

$options[] = array(
	'name' => 'Radio Example',
	'id' => 'radio',
	'type' => 'radio',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'options' => array(
		'1' => 'Radio 1',
		'2' => 'Radio 2',
		'3' => 'Radio 3',
		'4' => 'Radio 4',
		'5' => 'Radio 5',
		'6' => 'Radio 6',
		'7' => 'Radio 7',
		'8' => 'Radio 8',
	)
);
// Radio Option Include
echo get_option('radio');
//////////////////////////////////////////////////////////////////////
// Multicheck Option

$options[] = array(
	'name' => 'Multicheck Example',
	'id' => 'multicheck',
	'type' => 'multicheck',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'options' => array(
		'1' => 'Multicheck 1',
		'2' => 'Multicheck 2',
		'3' => 'Multicheck 3',
		'4' => 'Multicheck 4',
		'5' => 'Multicheck 5',
		'6' => 'Multicheck 6',
		'7' => 'Multicheck 7',
		'8' => 'Multicheck 8',
	)
);
// Multicheck Include
$checks = get_option('multicheck');
foreach( $checks as $k => $check ) {
	echo $check;
	echo $k;
}
//////////////////////////////////////////////////////////////////////
// Text Url Option

$options[] = array(
	'name' => 'Text Url Example',
	'id' => 'text_url',
	'type' => 'text_url',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Text Url Include
echo get_option('text_url');
//////////////////////////////////////////////////////////////////////
// Text Time Option

$options[] = array(
	'name' => 'Text Time Example',
	'id' => 'time_picker',
	'type' => 'time',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Text Time Include
echo get_option('time_picker');
//////////////////////////////////////////////////////////////////////
// Select Time Zone Option

$options[] = array(
	'name' => 'Select Time Zone Example',
	'id' => 'time_zone',
	'type' => 'timezone',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Select Time Zone Include
echo get_option('time_zone');
//////////////////////////////////////////////////////////////////////
// Select Time Zone Option

$options[] = array(
	'name' => 'Select Time Zone Example',
	'id' => 'time_zone',
	'type' => 'timezone',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Select Time Zone Include
echo get_option('time_zone');
//////////////////////////////////////////////////////////////////////
// Select Date And Time Option

$options[] = array(
	'name' => 'Select Date And Time Example',
	'id' => 'datetime',
	'type' => 'datetime',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Select Date And Time Include
echo get_option('datetime');
//////////////////////////////////////////////////////////////////////
// Textarea CSS Option

$options[] = array(
	'name' => 'Textarea CSS',
	'id' => 'textarea_css',
	'type' => 'textarea_css',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Textarea CSS Include
echo get_option('textarea_css');
//////////////////////////////////////////////////////////////////////
// Textarea HTML Option

$options[] = array(
	'name' => 'Textarea HTML',
	'id' => 'textarea_html',
	'type' => 'textarea_html',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
);
// Textarea HTML Include
echo get_option('textarea_html');
//////////////////////////////////////////////////////////////////////
// Radio Taxonomy Option

$options[] = array(
	'name' => 'Radio Example',
	'id' => 'radio_taxonomy',
	'type' => 'radio_taxonomy',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'tax' => 'quotes_cat',
);
// Radio Taxonomy Include
echo get_option('radio_taxonomy');
//////////////////////////////////////////////////////////////////////
// Multicheck Taxonomy Option

$options[] = array(
	'name' => 'Multicheck Example',
	'id' => 'multicheck_taxonomy',
	'type' => 'multi_taxonomy',
	'to' => 'tab_head',
	'desc' => 'Desc Example Desc Example Desc Example Desc Example .',
	'tax' => 'quotes_cat',
);
// Multicheck Taxonomy Include
$checks = get_option('multicheck_taxonomy');
foreach( $checks as $k => $check ) {
	echo $check;
	echo $k;
}
//////////////////////////////////////////////////////////////////////
