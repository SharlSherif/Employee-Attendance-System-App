<?php

ob_start();

define('WP_USE_THEMES', false);

$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );

require_once( $parse_uri[0] . 'wp-load.php' );

?>

<?php

$id = $_GET["id"];

$url = file_get_contents("http://www.omdbapi.com/?i=$id");

$json = json_decode($url, true); //This will convert it to an array

?>

<script>

$(document).ready(function(e) {

	<?

	$image_url  = $json['Poster'];

	$upload_dir = wp_upload_dir();

	$image_data = wp_remote_fopen($image_url);

	$filename = basename($image_url);

	$filename = str_replace('.jpg', '-'.$post_id.'.jpg', $filename);

	if(wp_mkdir_p($upload_dir['path']))

		$file = $upload_dir['path'] . '/' . $filename;

	else

		$file = $upload_dir['basedir'] . '/' . $filename;

	file_put_contents($file, $image_data);



	$wp_filetype = wp_check_filetype($filename, null );

	$attachment = array(

		'post_mime_type' => $wp_filetype['type'],

		'post_title' => sanitize_file_name($filename),

		'post_content' => '',

		'post_status' => 'inherit'

	);

	$attach_id = wp_insert_attachment( $attachment, $file, $post_id );

	require_once(ABSPATH . 'wp-admin/includes/image.php');

	$attach_data = wp_generate_attachment_metadata( $attach_id, $file );

	wp_update_attachment_metadata( $attach_id, $attach_data );



	set_post_thumbnail( $_GET['pid'], $attach_id );

	?>
	$('#postimagediv .inside a').html('<img src="<?=wp_get_attachment_url($attach_id)?>" />');

	<?php if( get_option('imdb_set_title') == 'yes' ) { ?>

    $('#Title').val('<?php echo str_replace('%s', $json['Title'], get_option('imdb_set_title_perma'))?>');

	<?php } ?>

	$('#title').val("<?php echo $json['Title']?>");

    $('#imdbRating').val('<?php echo $json['imdbRating']?>');
    $('#imdbVotes').val('<?php echo $json['imdbVotes']?>');
    $('#Released').val('<?php echo $json['Released']?>');
    $('#Runtime').val('<?php echo $json['Runtime']?>');
     $('#new-tag-Nation').val('<?php echo $json['Country']?>');

	$('#new-tag-director').val('<?php echo $json['Director']?>');
	$('#new-tag-country').val("<?php echo $json['Writer']?>");
	$('#new-tag-release-year').val('<?php echo $json['Year']?>');
	$('#new-tag-star').val("<?php echo $json['Actors']?>");
	$('#new-tag-genre').val('<?php echo $json['Genre']?>');
	$('#Awards').val('<?php echo $json['Awards']?>');
	$('#new-tag-Rated').val('<?php echo $json['Rated']?>');
	<?php
	require get_template_directory().'/imdb/class_IMDb.php';
	$imdb_2 = new IMDb(true);
	$imdb_2->summary=false;
	
	$q = trim(stripslashes($_GET['id']));
	$movie_2 = $imdb_2->find_by_id($q);
	?>

<? $trailers = array(); ?>
<? $trailers = (!empty($movie_2->trailer->encodings)) ? $movie_2->trailer->encodings : array(); ?>
<?php $i = 0; foreach( $trailers as $triler ) { ?>
		<?php if( $i == 0 ) { ?>

			<?php $trilerLink = '<video controls="" name="media"><source src="'.$triler->url.'" type="video/mp4"></video>'; ?>
		<?php } ?>
	<?php $i++; } ?>
	$('#').val('<?php echo $trilerLink?>');
});
</script>
<?=$_GET['pid']?>