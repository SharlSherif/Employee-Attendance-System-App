/////////////////////////////////
// carouFredSel
/////////////////////////////////
$(function() {
	$(".slides").owlCarousel({
		items: 6,
		stopOnHover: true,
		autoPlay: 10000,
		addClassActive: true,
		navigationText : ["prev","next"],
	});
	var owl2 = $(".slides").data('owlCarousel');
	$('.slides-next').click(function(){
		owl2.prev();
	});
	$('.slides-prev').click(function(){
		owl2.next();
	});
	$(".genres").owlCarousel({
		items: 8,
		responsive:false,
		stopOnHover: true,
		autoPlay: 10000,
		navigationText : ["prev","next"],
	});
	var owl = $(".genres").data('owlCarousel');
	$('.owl-next').click(function(){
		owl.prev();
	});
	$('.owl-prev').click(function(){
		owl.next();
	});
});