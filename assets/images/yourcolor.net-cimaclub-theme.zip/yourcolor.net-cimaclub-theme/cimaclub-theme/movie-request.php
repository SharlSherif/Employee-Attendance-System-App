<?php get_header(); 
?>



<div align="center">

<table border="0" width="100%" bgcolor="#FFFFFF">
	<tr>
		<td bgcolor="#FFFFFF">



<div align="center">



<table border="0" width="74%" bgcolor="#FFFFFF">
	<tr>
		<td bgcolor="#FFFFFF">


<p align="left" dir="ltr">

<b>Rules:- <br>
1. Search before placing a request, use search box to check the movie. 
<br>
2. Leave your comment with movie title, ( Year ) The Green Mile (1999) </b>

</p>
<p align="left">

&nbsp;</p>
<p align="right" dir="rtl">

<b><font color="#FF0000">القوانين : <br>
1 – تأكد من عدم وجود الفيلم أو المسلسل عن طريق صندوق البحث بالأعلى <br>
2 
– إترك تعليق بإسم الفيلم مع تاريخ انتاجه أو رابط للفيلم على الـ IMDB</font></b></p>



<?php the_content(); ?>
<?php include_once 'commentfb.php'; ?>




<div align="center">
	<table border="0" width="13%" cellspacing="0" cellpadding="0">
		<tr>
			<td>
</td>
		</tr>
	</table>

</div>



</td>
	</tr>
</table>

</div>

</td>
	</tr>
</table>
</div>


        
     


<div class="footer">
	<div class="container">
		<div class="alignright">
			جميع الحقوق محفوظة <a href="<?=home_url()?>" title="<? bloginfo('name'); ?>"><? bloginfo('name'); ?></a> &copy; <?=date('Y')?>
		</div>
		<div class="alignleft">
			تصميم و برمجة <a href="http://www.yourcolor.net" title="تصميم مواقع | برمجة خاصة | برمجة ووردبريس | استضافة" alt="تصميم و برمجة و استضافة">YourColor.net - ورشة لونك</a>
		</div>
	</div>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>