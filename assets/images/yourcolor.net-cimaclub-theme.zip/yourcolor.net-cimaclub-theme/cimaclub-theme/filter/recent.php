<? if ( array_key_exists('page', $_GET) ) { $paged = $_GET['page']; } else {$paged = ''; } ?>
<?php
ob_start();
define('WP_USE_THEMES', false);
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
if( !empty($paged) ) {
	header('Location: '.home_url().'?page='.$paged.'');
	die();
}
?>
<? $postsNotin = array(); ?>
<? query_posts(array('post_type'=>'post', 'meta_key' => 'pin', 'posts_per_page'=>-1)); ?>
<? $blo = 1; if(have_posts()) { while(have_posts()) { the_post(); ?>
	<? $postsNotin[] = $post->ID; ?>
<? } } ?>
<? query_posts(array('post_type'=>'post', 'meta_key' => 'pin_normal', 'posts_per_page'=>-1)); ?>
<? $blo = 1; if(have_posts()) { while(have_posts()) { the_post(); ?>
	<? $postsNotin[] = $post->ID; ?>
<? } } ?>
<? query_posts(array('post_type'=>'post', 'paged'=>$paged, 'post__not_in'=>array_values($postsNotin), 'posts_per_page'=>54)); ?>
<? if(have_posts()) { while(have_posts()) { the_post(); ?>
	<? require(get_template_directory().'/film.php'); ?>
<? } } ?>
<div class="pagination">
   <?php paginate(); ?>
   <?
   $wp_query = null;
   $wp_query = $temp; // Reset
   ?>
</div>