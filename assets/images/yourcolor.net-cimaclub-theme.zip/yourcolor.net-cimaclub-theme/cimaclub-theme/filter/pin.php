<? if ( array_key_exists('page', $_GET) ) { $paged = $_GET['page']; } else {$paged = ''; } ?>

<?php

ob_start();

define('WP_USE_THEMES', false);

$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );

require_once( $parse_uri[0] . 'wp-load.php' );

if( !empty($paged) ) {

	header('Location: '.home_url().'?page='.$paged.'&type=pin');

	die();

}

?>

<? query_posts(array('post_type'=>'post', 'paged'=>$paged, 'orderby'=>'meta_value_num&order=desc', 'meta_query' => array(array('key' => 'pin_normal', 'value' => 'on', 'compare' => '=='), ), 'posts_per_page'=>18)); ?>

<? if(have_posts()) { while(have_posts()) { the_post(); ?>

	<? require(get_template_directory().'/film.php'); ?>

<? } } ?>