<? if ( array_key_exists('page', $_GET) ) { $paged = $_GET['page']; } else {$paged = ''; } ?>
<?php
ob_start();
define('WP_USE_THEMES', false);
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
if( !empty($paged) ) {
	header('Location: '.home_url().'?page='.$paged.'&type=topratings');
	die();
}
?>
<? if ( array_key_exists('page', $_GET) ) { $paged = $_GET['page']; } else {$paged = 1; } ?>
<? query_posts(array('post_type'=>'post', 'meta_key'=>'imdbRating', 'cat'=>391, 'paged'=>$paged, 'orderby'=>'meta_value_num', 'posts_per_page'=>18)); ?>
<? if(have_posts()) { while(have_posts()) { the_post(); ?>
	<? require(get_template_directory().'/film.php'); ?>
<? } } ?>
<a href="<?=home_url()?>/top-imdb" class="top-imdbButtonMore">مزيد من الاعلي تقييما</a>