<?php function YC_admin_style() { ?>
<style>
#toplevel_page_YC_panel {
display: none;
}
</style>
<?php }
add_action( 'admin_enqueue_scripts', 'YC_admin_style' );
if ( ! function_exists( 'yourcolor_setup2' ) ) :
function yourcolor_setup2() {
	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'footer-menu-2'   => __( 'قائمة الفوتر البلوكات', 'YourColor' ),
	) );
}
endif;
add_action( 'after_setup_theme', 'yourcolor_setup2' );
require_once get_template_directory().'/functions/admin/YC-itc.php';
/**
 * Deregister matching post types.
 */
function custom_unregister_theme_post_types() {
    global $wp_post_types;
    foreach( array( 'episodes', 'tvshows' ) as $post_type ) {
        if ( isset( $wp_post_types[ $post_type ] ) ) {
            unset( $wp_post_types[ $post_type ] );
        }
    }
}
add_action( 'init', 'custom_unregister_theme_post_types', 20 );

/**
 * Remove matching post types from list of post types supported by Themify.
 *
 * @param $types
 * @return array
 */
function custom_supported_post_types( $types ) {
    $removed_types = array( 'episodes', 'tvshows' );
    return array_diff( $types, $removed_types );
}
add_action( 'themify_post_types', 'custom_supported_post_types', 77 );

/**
 * Remove matching post types from Builder module list.
 *
 * @param $types
 * @return array
 */
function custom_builder_modules( $types ) {
    $removed_types = array( 'episodes', 'tvshows' );
    return array_diff( $types, $removed_types );
}
add_filter( 'themify_builder_modules_list', 'custom_builder_modules' );





	function dez_schema_breadcrumb2() {







	global $post;







	//schema link







	$schema_link = 'http://data-vocabulary.org/Breadcrumb';







	$home = 'الرئيسية';







	$delimiter = ' &raquo; ';







	$homeLink = get_bloginfo('url');







	if (is_home() || is_front_page()) {







	// no need for breadcrumbs in homepage







	}







	else {







	echo '<div id="mpbreadcrumbs">';







	// main breadcrumbs lead to homepage







	if (!is_single()) {







	echo 'You are here: ';







	}







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . $homeLink . '">' . '<span itemprop="title">' . $home . '</span>' . '</a></span>' . $delimiter . ' ';







	// if blog page exists







	if (get_page_by_path('blog')) {







	if (!is_page('blog')) {







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_permalink(get_page_by_path('blog')) . '">' . '<span itemprop="title">Blog</span></a></span>' . $delimiter . ' ';







	}







	}







	if (is_category()) {







	$thisCat = get_category(get_query_var('cat'), false);







	if ($thisCat->parent != 0) {







	$category_link = get_category_link($thisCat->parent);







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . $category_link . '">' . '<span itemprop="title">' . get_cat_name($thisCat->parent) . '</span>' . '</a></span>' . $delimiter . ' ';







	}







	$category_id = get_cat_ID(single_cat_title('', false));







	$category_link = get_category_link($category_id);







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . $category_link . '">' . '<span itemprop="title">' . single_cat_title('', false) . '</span>' . '</a></span>';







	}







	elseif (is_single() && !is_attachment()) {







	if (get_post_type() != 'post') {







	$post_type = get_post_type_object(get_post_type());







	$slug = $post_type->rewrite;







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . $homeLink . '/' . $slug['slug'] . '">' . '<span itemprop="title">' . $post_type->labels->singular_name . '</span>' . '</a></span>';







	echo ' ' . $delimiter . ' ' . get_the_title();







	}







	else {







	$category = get_the_category();







	if ($category) {







	foreach ($category as $cat) {







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_category_link($cat->term_id) . '">' . '<span itemprop="title">' . $cat->name . '</span>' . '</a></span>' . $delimiter . ' ';







	}







	}







	$category = get_the_terms($post->ID, 'series', '');







	if ($category) {







		foreach ($category as $cat) {







		echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_category_link($cat->term_id) . '">' . '<span itemprop="title">' . $cat->name . '</span>' . '</a></span>' . $delimiter . ' ';







		}







	}







	echo get_the_title();







	}







	}







	elseif (!is_single() && !is_page() && get_post_type() != 'post' && !is_404()) {







	$post_type = get_post_type_object(get_post_type());







	echo $post_type->labels->singular_name;







	}







	elseif (is_attachment()) {







	$parent = get_post($post->post_parent);







	$cat = get_the_category($parent->ID);







	$cat = $cat[0];







	echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_permalink($parent) . '">' . '<span itemprop="title">' . $parent->post_title . '</span>' . '</a></span>';







	echo ' ' . $delimiter . ' ' . get_the_title();







	}







	elseif (is_page() && !$post->post_parent) {







	$get_post_slug = $post->post_name;







	$post_slug = str_replace('-', ' ', $get_post_slug);







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_permalink() . '">' . '<span itemprop="title">' . ucfirst($post_slug) . '</span>' . '</a></span>';







	}







	elseif (is_page() && $post->post_parent) {







	$parent_id = $post->post_parent;







	$breadcrumbs = array();







	while ($parent_id) {







	$page = get_page($parent_id);







	$breadcrumbs[] = '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_permalink($page->ID) . '">' . '<span itemprop="title">' . get_the_title($page->ID) . '</span>' . '</a></span>';







	$parent_id = $page->post_parent;







	}







	$breadcrumbs = array_reverse($breadcrumbs);







	for ($i = 0; $i < count($breadcrumbs); $i++) {







	echo $breadcrumbs[$i];







	if ($i != count($breadcrumbs) - 1)







	echo ' ' . $delimiter . ' ';







	}







	echo $delimiter . '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_permalink() . '">' . '<span itemprop="title">' . the_title_attribute('echo=0') . '</span>' . '</a></span>';







	}







	elseif (is_tag()) {







	$tag_id = get_term_by('name', single_cat_title('', false), 'post_tag');







	if ($tag_id) {







	$tag_link = get_tag_link($tag_id->term_id);







	}







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . $tag_link . '">' . '<span itemprop="title">' . single_cat_title('', false) . '</span>' . '</a></span>';







	}







	elseif (is_author()) {







	global $author;







	$userdata = get_userdata($author);







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_author_posts_url($userdata->ID) . '">' . '<span itemprop="title">' . $userdata->display_name . '</span>' . '</a></span>';







	}







	elseif (is_404()) {







	echo 'Error 404';







	}







	elseif (is_search()) {







	echo 'Search results for "' . get_search_query() . '"';







	}







	elseif (is_day()) {







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_year_link(get_the_time('Y')) . '">' . '<span itemprop="title">' . get_the_time('Y') . '</span>' . '</a></span>' . $delimiter . ' ';







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . '<span itemprop="title">' . get_the_time('F') . '</span>' . '</a></span>' . $delimiter . ' ';







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')) . '">' . '<span itemprop="title">' . get_the_time('d') . '</span>' . '</a></span>';







	}







	elseif (is_month()) {







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_year_link(get_the_time('Y')) . '">' . '<span itemprop="title">' . get_the_time('Y') . '</span>' . '</a></span>' . $delimiter . ' ';







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . '<span itemprop="title">' . get_the_time('F') . '</span>' . '</a></span>';







	}







	elseif (is_year()) {







	echo '<span itemscope itemtype="' . $schema_link . '"><a itemprop="url" href="' . get_year_link(get_the_time('Y')) . '">' . '<span itemprop="title">' . get_the_time('Y') . '</span>' . '</a></span>';







	}







	if (get_query_var('paged')) {







	if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author())







	echo ' (';







	echo __('Page') . ' ' . get_query_var('paged');







	if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author())







	echo ')';







	}







	echo '</div>';







	}







	}







/**







 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB directory)







 *







 * @category YourThemeOrPlugin







 * @package  Metaboxes







 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)







 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-WordPress







 */















/**







 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!







 */







if ( file_exists(  __DIR__ . '/CustomMetaBox/init.php' ) ) {







	require_once  __DIR__ . '/CustomMetaBox/init.php';







} elseif ( file_exists(  __DIR__ . '/CustomMetaBox/init.php' ) ) {







	require_once  __DIR__ . '/CustomMetaBox/init.php';







}















/**







 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter







 *







 * @param  CMB2_Field object $field Field object







 *







 * @return bool True if metabox should show







 */







function cmb2_hide_if_no_cats( $field ) {







	// Don't show this field if not in the cats category







	if ( ! has_tag( 'cats', $field->object_id ) ) {







		return false;







	}







	return true;







}















add_filter( 'cmb2_meta_boxes', 'cmb2_sample_metaboxes' );







































































// CIMACLUB EDIT HoSs







function my_search_pre_get_posts($query)



{



    // Verify that we are on the search page that that this came from the event search form



    if($query->query_vars['s'] != '' && is_search())



    {



        // If "s" is a positive integer, assume post id search and change the search variables



        if(absint($query->query_vars['s']))



        {



            // Set the post id value



            $query->set('p', $query->query_vars['s']);



            // Reset the search value



            $query->set('s', '');



        }



    }



}



add_filter('pre_get_posts', 'my_search_pre_get_posts');











































add_action( 'init', 'register_my_taxonomies', 0 );
function register_my_taxonomies() {
	register_taxonomy(
		'Rated',
		array( 'post' ),
		array(
			'public' => true,
			'labels' => array(
				'name' => __( 'تصنيف المحتوى' ),
				'singular_name' => __( 'Rated' )
			),
		)
	);



	register_taxonomy(
		'Nation',
		array( 'post' ),
		array(
			'public' => true,
			'labels' => array(
				'name' => __( 'البلد' ),
				'singular_name' => __( 'Nation' )
			),
		)
	);




}





































































































































































/**







 * Define the metabox and field configurations.







 *







 * @param  array $meta_boxes







 * @return array







 */







function cmb2_sample_metaboxes( array $meta_boxes ) {















	// Start with an underscore to hide fields from custom fields list







	$prefix = '';







	$meta_boxes['seo_pages'] = array(







		'id'            => 'seo_pages',







		'title'         => __( 'اعدادات الارشفة', 'cmb' ),







		'object_types'  => array( 'page', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'name' => 'محتوي الارشفة',







				'id'   => 'seo_desc',







				'type' => 'text',







			),







			array(







				'name' => 'كلمات ارشفية',







				'id'   => 'seo_keywords',







				'type' => 'text',







			),







		),







	);







	$meta_boxes['seo_posts'] = array(







		'id'            => 'seo_posts',







		'title'         => __( 'اعدادات الارشفة', 'cmb' ),







		'object_types'  => array( 'post', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'name' => 'محتوي الارشفة',







				'id'   => 'seo_desc',







				'type' => 'text',







			),







		),







	);







	if( is_user_logged_in() ){







		global $current_user;







		$current_user = wp_get_current_user();







		if ( !($current_user instanceof WP_User) )







		   return;







		$roles = $current_user->roles;  //$roles is an array







	}else {







		$roles = array( 0 => '' );







	}







	if( $roles[0] != 'author' ) {







		$pin = array(







			'name' => 'مثبت مميز',







			'id'   => 'pin',







			'type' => 'checkbox',







		);







		query_posts(array('post_type'=>'post', 'meta_key'=>'pin_numeric', 'orderby'=>'meta_value_num', 'meta_query' => array(array('key' => 'pin', 'value' => 'on', 'compare' => '=='), ), 'posts_per_page'=>1));







		if(have_posts()) { while(have_posts()) { the_post();







			global $post;







			$last = get_post_meta($post->ID, 'pin_numeric', true);







		} } wp_reset_query();







		$pin_numeric = array(







			'name' => 'رقم التثبيت',







			'id'   => 'pin_numeric',







			'type' => 'text',







			'default' => 'اخر رقم : '.$last,







		);







	}







	$meta_boxes['post'] = array(







		'id'            => 'post',







		'title'         => __( 'اعدادات الفيلم', 'cmb' ),







		'object_types'  => array( 'post', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'name' => 'مسلسل رئيسي',







				'id'   => 'mainserie',







				'type' => 'checkbox',







			),







			array(







				'name' => 'رقم الحلقة',







				'id'   => 'number',







				'type' => 'text',







			),







		array(







				'name' => 'Youtube',







				'id'   => 'hoss',







				'type' => 'textarea_code',







			),







	array(







				'name' => 'تاريخ الصدور',







				'id'   => 'Released',







				'type' => 'text',







			),



















	array(







				'name' => 'EMBED',







				'id'   => 'hoss2',







				'type' => 'text',







			),











			array(







				'name' => 'مدة التشغيل',







				'id'   => 'Runtime',







				'type' => 'text',







				'description'=>'<strong style="color:red;">ملحوظ هاااامة : </strong>يرجي كتابة المدة بالصيغة الاتية : <strong style="color:green;">35:00</strong> ليتم تفعيل ارشفة المقال بالطريقة الصحيحة'







			),







			array(







				'name' => 'رابط تحميل مباشر',







				'id'   => 'download_full',







				'type' => 'text',







			),







			array(







				'name' => 'رقم الجزء',







				'id'   => 'numbermov',







				'type' => 'text',







			),







			array(







				'name' => 'الملصق',







				'id'   => 'ribbon',







				'type' => 'text',







			),







			$pin,







			$pin_numeric,







			array(







				'name' => 'مثبت عادي',







				'id'   => 'pin_normal',







				'type' => 'checkbox',







			),







			array(







				'name' => 'Awards',







				'id'   => 'Awards',







				'type' => 'text',







			),











			array(







				'name' => 'IMDB Ratings',







				'id'   => 'imdbRating',







				'type' => 'text',







			),







			array(







				'name' => 'IMDB Votes',







				'id'   => 'imdbVotes',







				'type' => 'text',







			),







			array(







				'name' => 'IMDB Poster',







				'id'   => 'IMDB_poster',







				'type' => 'text_url',







			),







			array(







				'name' => 'IMDB ID',







				'id'   => 'imdb_id',







				'type' => 'text',







			),







			array(







				'name' => 'IMDB',







				'id'   => 'imdb',







				'type' => 'text',







			),







			array(







				'name' => 'صور الفيلم',







				'id'   => 'photos',







				'type' => 'file_list',







			),







		),







	);







	$meta_boxes['post_2'] = array(







		'id'            => 'post_2',







		'title'         => __( 'سيرفرات المشاهدة', 'cmb' ),







		'object_types'  => array( 'post', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'id'          => 'watch',







				'type'        => 'group',







				'options'     => array(







					'group_title'   => __( 'سيرفرات المشاهدة {#}', 'cmb2' ), // {#} gets replaced by row number







					'add_button'    => __( 'اضافة سيرفر', 'cmb2' ),







					'remove_button' => __( 'ازالة السيرفر', 'cmb2' ),







					'sortable'      => true, // beta







				),







				// Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.







				'fields'      => array(







					array(







						'name' => 'الكود',







						'id'   => 'embed',







						'type' => 'textarea_code',







					),







				),







			),







		),







	);







	$meta_boxes['post_3'] = array(







		'id'            => 'post_3',







		'title'         => __( 'سيرفرات التحميل', 'cmb' ),







		'object_types'  => array( 'post', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'id'          => 'download',







				'type'        => 'group',







				'options'     => array(







					'group_title'   => __( 'سيرفرات التحميل {#}', 'cmb2' ), // {#} gets replaced by row number







					'add_button'    => __( 'اضافة سيرفر', 'cmb2' ),







					'remove_button' => __( 'ازالة السيرفر', 'cmb2' ),







					'sortable'      => true, // beta







				),







				// Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.







				'fields'      => array(







					array(







						'name' => 'اسم السيرفر',







						'id'   => 'name',







						'type' => 'text',







					),







					array(







						'name' => 'رابط السيرفر',







						'id'   => 'link',







						'type' => 'textarea_code',







					),







					array(







						'name' => 'الجودة',







						'id'   => 'quality',







						'type' => 'text',







					),







					array(







						'name' => 'الحجم',







						'id'   => 'size',







						'type' => 'text',







					),







				),







			),







		),







	);







	$meta_boxes['post_2'] = array(







		'id'            => 'post_2',







		'title'         => __( 'سيرفرات المشاهدة', 'cmb' ),







		'object_types'  => array( 'post', ), // Post type







		'context'       => 'normal',







		'priority'      => 'high',







		'show_names'    => true, // Show field names on the left







		'fields'     => array(







			array(







				'id'          => 'watch',







				'type'        => 'group',







				'options'     => array(







					'group_title'   => __( 'سيرفرات المشاهدة {#}', 'cmb2' ), // {#} gets replaced by row number







					'add_button'    => __( 'اضافة سيرفر', 'cmb2' ),







					'remove_button' => __( 'ازالة السيرفر', 'cmb2' ),







					'sortable'      => true, // beta







				),







				// Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.







				'fields'      => array(







					array(







						'name' => 'الكود',







						'id'   => 'embed',







						'type' => 'textarea_code',







					),







				),







			),







		),







	);







	//////////////////////////////////////







	// Ads Management







	//////////////////////////////////////







	$meta_boxes['ads_sett'] = array(







		'id'           => 'ads_sett',







		'title'        => __( 'اعدادات الاعلان', 'cmb2' ),







		'object_types' => array( 'ads', ),







		'fields'       => array(







			array(







				'name' => __('حجم الاعلان' , 'YourColor'),







				'id' => 'size' ,







				'type' => 'select',







				'options'=> ads_sizes()







			),







			/////////////////////////////////////////







			/////////////////////////////////////////







			array(







				'name' => __('كود الاعلان' , 'YourColor'),







				'id' => $prefix . 'code' ,







				'type' => 'textarea_code',







			),







			/////////////////////////////////////////







			/////////////////////////////////////////







			array(







				'name' => __('كود الاعلان - موبايل' , 'YourColor'),







				'id' => $prefix . 'code_mobile' ,







				'type' => 'textarea_code',







			),







			/////////////////////////////////////////







			/////////////////////////////////////////







		),







	);







	///////////////////////////////////







	// Seo Post







	///////////////////////////////////







	$meta_boxes['option_seo'] = array(







		'id'           => 'option_seo',







		'title'        => __( 'اعدادات الارشفة', 'cmb' ),







		'object_types' => array( 'post' , 'page'),







		'fields'       => array(







			array(







				'name' => 'عنوان الموضوع',







				'id'   => 'name_seo',







				'type' => 'text',







			),







			array(







				'name' => 'وصف الموضوع',







				'id'   => 'desc_seo',







				'type' => 'textarea',







			),







			array(







				'name' => 'وسوم الموضوع',







				'id'   => 'tags_seo',







				'type' => 'text',







			),







			array(







				'name' => 'صورة الشير ',







				'id'   => 'img_social',







				'type' => 'file',







			),







		),







	);







	/////////////////////////////////////////







	/////////////////////////////////////////







	// Add other metaboxes as needed















	return $meta_boxes;







}







