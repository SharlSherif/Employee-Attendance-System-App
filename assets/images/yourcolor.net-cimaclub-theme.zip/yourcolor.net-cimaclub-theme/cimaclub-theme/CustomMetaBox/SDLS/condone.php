<?php
define('sSECURE_AUTH_KEY', "http://eljded.com/fady");
