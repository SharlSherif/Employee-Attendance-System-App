<?php
//////////////////////////////////////////////////////////////////
// meta header
//////////////////////////////////////////////////////////////////
function add_meta_tags() {
global $post;?>
<?php if(is_home()){ ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<title><?php echo $title_home; ?></title>
<?php }else{ ?>
<title><?php bloginfo('name'); ?></title>
<?php } ?>
<?php 
$description_home = get_option('s_description_home');
if(!empty($description_home)){ 
?>
<meta name="description" content="<?php echo $description_home; ?>" />
<?php }else{ ?>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<?php } ?>
<?php 
$tags_home = get_option('s_tags_home');
if(!empty($tags_home)){ 
?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tags_home; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:title" content="<?php echo $title_home?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
$description_home = get_option('s_description_home');
if(!empty($description_home)){ 
?>
<meta property="og:description" content="<?php echo $description_home; ?>"/>
<?php }else{ ?>
<meta property="og:description" content="<?php bloginfo('description'); ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_404()){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php $s404 = get_option('s_404'); ?>
<?php if(!empty($s404)) { ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<title><?php echo $s404; ?> | <?php echo $title_home; ?></title>
<?php }else{ ?>
<title><?php echo $s404; ?> | <?php bloginfo('name'); ?></title>
<?php } ?>
<?php }else{ ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<title><?php _e( 'خطأ 404' , 'YourColor' ); ?> | <?php echo $title_home; ?></title>
<?php }else{ ?>
<title><?php _e( 'خطأ 404' , 'YourColor' ); ?> | <?php bloginfo('name'); ?></title>
<?php } ?>
<?php } ?>
<?php 
$description_home = get_option('s_description_home');
if(!empty($description_home)){ 
?>
<meta name="description" content="<?php echo $description_home; ?>" />
<?php }else{ ?>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<?php } ?>
<?php 
$tags_home = get_option('s_tags_home');
if(!empty($tags_home)){ 
?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tags_home; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php $s404 = get_option('s_404'); ?>
<?php if(!empty($s404)) { ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:title" content="<?php echo $s404; ?> | <?php echo $title_home?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php echo $s404; ?> | <?php bloginfo('name'); ?>" />
<?php } ?>
<?php }else{ ?>
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:title" content="<?php _e( 'خطأ 404' , 'YourColor' ); ?> | <?php echo $title_home?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php _e( 'خطأ 404' , 'YourColor' ); ?> | <?php bloginfo('name'); ?>" />
<?php } ?>
<?php } ?>
<?php 
$description_home = get_option('s_description_home');
if(!empty($description_home)){ 
?>
<meta property="og:description" content="<?php echo $description_home; ?>"/>
<?php }else{ ?>
<meta property="og:description" content="<?php bloginfo('description'); ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_category()){ 
global $wpdb
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$category = get_the_category(); 
////////////////////////////////
////////////////////////////////
$cat_id   = $category[0]->term_id;
////////////////////////////////
////////////////////////////////
$custom_data = get_option("category_".$cat_id);
$title_cat = $custom_data['title_seo']; 
$descr_cat = $custom_data['description_seo']; 
$tag_cat   = $custom_data['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<meta name="description" content="<?php echo category_description($cat_id); ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<meta property="og:description" content="<?php echo category_description($cat_id); ?>"/>
<?php } ?>
<meta property="og:type" content="video.movie" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tag()){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$category = get_the_category(); 
////////////////////////////////
////////////////////////////////
$cat_id   = $category[0]->term_id;
////////////////////////////////
////////////////////////////////
?>
<title><?php single_cat_title(); ?></title>
<meta name="description" content="<?php echo category_description($cat_id); ?>" />
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<meta property="og:description" content="<?php echo category_description($cat_id); ?>"/>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('type_cat')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$type_cat = get_option("type_cat_term_".$cat_id);
$title_cat = $type_cat['title_seo']; 
$descr_cat = $type_cat['description_seo']; 
$tag_cat   = $type_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'type_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'type_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('director')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$director_cat = get_option("director_term_".$cat_id);
$title_cat = $director_cat['title_seo']; 
$descr_cat = $director_cat['description_seo']; 
$tag_cat   = $director_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'director'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($director_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $director_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'director_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('escritor')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$writer_cat = get_option("escritor_term_".$cat_id);
$title_cat = $writer_cat['title_seo']; 
$descr_cat = $writer_cat['description_seo']; 
$tag_cat   = $writer_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'escritor'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($writer_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $writer_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'escritor'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('actor')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$actors_cat = get_option("actor_term_".$cat_id);
$title_cat = $actors_cat['title_seo']; 
$descr_cat = $actors_cat['description_seo']; 
$tag_cat   = $actors_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'actor'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($actors_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $actors_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'actor'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('country')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$country_cat = get_option("country_term_".$cat_id);
$title_cat = $country_cat['title_seo']; 
$descr_cat = $country_cat['description_seo']; 
$tag_cat   = $country_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'country'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($country_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $country_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'country'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('language')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$language_cat = get_option("language_term_".$cat_id);
$title_cat = $language_cat['title_seo']; 
$descr_cat = $language_cat['description_seo']; 
$tag_cat   = $language_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'language'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'language'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('quality')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$quality_cat = get_option("quality_term_".$cat_id);
$title_cat = $quality_cat['title_seo']; 
$descr_cat = $quality_cat['description_seo']; 
$tag_cat   = $quality_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'quality'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'quality'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('year')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$year_cat = get_option("year_term_".$cat_id);
$title_cat = $year_cat['title_seo']; 
$descr_cat = $year_cat['description_seo']; 
$tag_cat   = $year_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'year'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php if(!empty($logo)) {?>
<meta property="og:image" content="<?php echo $logo; ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'year'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('selary_cat')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$selary_cat = get_option("selary_cat_term_".$cat_id);
$title_cat = $selary_cat['title_seo']; 
$descr_cat = $selary_cat['description_seo']; 
$tag_cat   = $selary_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'selary_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($selary_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $selary_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'selary_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_tax('production_cat')){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );	
////////////////////////////////
////////////////////////////////
$cat_id   = $term->term_id;
////////////////////////////////
////////////////////////////////
$production_cat = get_option("production_cat_term_".$cat_id);
$title_cat = $production_cat['title_seo']; 
$descr_cat = $production_cat['description_seo']; 
$tag_cat   = $production_cat['tag_seo']; 
////////////////////////////////
////////////////////////////////
if(!empty($title_cat)) { 
?>
<title><?php echo $title_cat; ?></title>
<?php }else{ ?>
<title><?php single_cat_title(); ?></title>
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta name="description" content="<?php echo $descr_cat; ?>" />
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'production_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta name="description" content="<?php echo $dexs; ?>" />
<?php } ?>
<?php if(!empty($tag_cat)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tag_cat; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php if( !empty($production_cat['icon'])){ ?>
<meta property="og:image" content="<?php echo $production_cat['icon']; ?>" />
<?php }else{ ?>
<meta property="og:image" content="<?php echo get_option('logo'); ?>" />
<?php } ?>
<?php 
if(!empty($title_cat)) { 
?>
<meta property="og:title" content="<?php echo $title_cat; ?>" />
<?php }else{ ?>
<meta property="og:title" content="<?php single_cat_title(); ?>" />
<?php } ?>
<?php if(!empty($descr_cat)){ ?>
<meta property="og:description" content="<?php echo $descr_cat; ?>"/>
<?php }else{ ?>
<?php 
$dexs = substr(term_description($cat_id,'production_cat'), 0, 156);
$dexs = strip_tags($dexs, '')
?>
<meta property="og:description" content="<?php echo $dexs; ?>"/>
<?php } ?>
<meta property="og:type" content="website" />
<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<?php 
$title_home = get_option('s_title_home');
if(!empty($title_home)){ 
?>
<meta property="og:site_name" content="<?php echo $title_home; ?>" />
<?php }else{ ?>
<meta property="og:site_name" content="<?php bloginfo('name'); ?>" />
<?php } ?>
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_single()){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$title_single = get_post_meta( $post->ID , 'name_seo' , true );  
$desc_single  = get_post_meta( $post->ID , 'desc_seo' , true );  
$tags_single  = get_post_meta( $post->ID , 'tags_seo' , true );  
$img_single   = get_post_meta( $post->ID , 'img_social' , true ); 
if(!empty($title_single)){  
?>
<title><? foreach (array_slice((is_array(get_the_terms($post->ID, 'category', ''))) ? get_the_terms($post->ID, 'category', '') : array(), 0, 1) as $tag) { ?><?=$tag->name?> - <? } ?> <?php echo $title_single; ?></title>
<?php }else{ ?>
<title><? foreach (array_slice((is_array(get_the_terms($post->ID, 'category', ''))) ? get_the_terms($post->ID, 'category', '') : array(), 0, 1) as $tag) { ?><?=$tag->name?> - <? } ?> <?php the_title(); ?></title>
<?php } ?>
<?php if(!empty($desc_single)){ ?>
<meta name="description" content="<?php echo wp_trim_words($desc_single, 25, '..'); ?>" />
<?php } ?>
<?php if(!empty($tags_single)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tags_single; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php 
//////////////////////////////////////////////
//////////////////////////////////////////////
}else if(is_page()){ 
//////////////////////////////////////////////
//////////////////////////////////////////////
?>
<?php
$title_single = get_post_meta( $post->ID , 'name_seo' , true );  
$desc_single  = get_post_meta( $post->ID , 'desc_seo' , true );  
$tags_single  = get_post_meta( $post->ID , 'tags_seo' , true );  
$img_single   = get_post_meta( $post->ID , 'img_social' , true ); 
if(!empty($title_single)){  
?>
<title><?php echo $title_single; ?></title>
<?php }else{ ?>
<title><?php the_title(); ?></title>
<?php } ?>
<?php if(!empty($desc_single)){ ?>
<meta name="description" content="<?php echo $desc_single; ?>" />
<?php } ?>
<?php if(!empty($tags_single)){ ?>
<meta name="keywords" itemprop="keywords" content="<?php echo $tags_single; ?>" />
<?php } ?>
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php }else{?>
<title><?php wp_title(); ?></title>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<link rel="canonical" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />        
<?php $logo = get_option('logo'); ?>
<?php } ?>
<?php
}
