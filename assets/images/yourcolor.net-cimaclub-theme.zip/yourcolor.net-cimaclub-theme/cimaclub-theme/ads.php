<? if( wp_is_mobile() ) { ?>


</div>

<? }else { ?>


<? } ?>